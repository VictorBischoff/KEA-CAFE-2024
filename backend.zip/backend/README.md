# Fullstack opgave KEA Victor Simon BACKEND

## Setting up database


